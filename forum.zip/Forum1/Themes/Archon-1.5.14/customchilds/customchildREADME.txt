==============================================
What are these custom child styles?
==============================================

These child styles are essentially a head start to a different setup of Archon. You can simply pick which one you'd like to work off of
and import it as a child style of Archon. You do NOT need to create an additional child of the newly imported style.
Once you import it you can rename it to whatever style name you would like and going forward put all of your edits into it.


==============================================
Upgrading
==============================================
On upgrades... DO NOT import and overwrite the Child Styles, only import and overwrite XenBase and Archon(the parents).


For further clarification or support please contact us on our site: https://pixelexit.com/