<?php

/**
 * This is a wrapper to maintain backwards compatibility. Use XenForo_Authentication_Core directly.
 *
 * @package XenForo_Authentication
 */
class XenForo_Authentication_Default extends XenForo_Authentication_Core
{
}