<?php if(!defined('VB_ENTRY')) die('Access denied.');
### start options ###
$options = '';
### end options ###

### start bitfields ###
$bitfields = '';
### end bitfields ###

### start forumcache ###
$forumcache = '';
### end forumcache ###

### start usergroupcache ###
$usergroupcache = '';
### end usergroupcache ###

### start stylecache ###
$stylecache = '';
### end stylecache ###

### start languagecache ###
$languagecache = '';
### end languagecache ###

### start products ###
$products = '';
### end products ###

### start hooks ###
$hooks = '';
### end hooks ###

?>
